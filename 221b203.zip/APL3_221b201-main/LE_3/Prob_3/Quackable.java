public interface Quackable {
    void quack();
}
