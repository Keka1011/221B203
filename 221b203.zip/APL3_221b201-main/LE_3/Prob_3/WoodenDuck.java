public class WoodenDuck implements Swimmable {
    @Override
    public void swim() {
        System.out.println("Wooden Duck is swimming.");
    }
}
