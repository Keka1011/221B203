public class Duryodhan extends Kaurav {
    @Override
    public void fight() {
        System.out.println("Duryodhan fights fiercely!");
    }

    @Override
    public void disobey() {
        System.out.println("Duryodhan disobeys the elders.");
    }

    @Override
    public void cruel() {
        System.out.println("Duryodhan is cruel and unforgiving.");
    }
}
