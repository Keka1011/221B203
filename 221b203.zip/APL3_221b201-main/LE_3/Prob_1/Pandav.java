public abstract class Pandav extends Bharatvanshi {
    public abstract void obey();
    public abstract void kind();
}
