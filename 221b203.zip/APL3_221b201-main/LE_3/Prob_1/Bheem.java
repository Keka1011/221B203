public class Bheem extends Pandav {
    @Override
    public void fight() {
        System.out.println("Bheem fights with great strength!");
    }

    @Override
    public void obey() {
        System.out.println("Bheem is obedient.");
    }

    @Override
    public void kind() {
        System.out.println("Bheem is less kind compared to Arjun.");
    }
}
