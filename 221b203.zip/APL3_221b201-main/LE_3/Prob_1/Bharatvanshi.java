public abstract class Bharatvanshi {
    public abstract void fight();
}
