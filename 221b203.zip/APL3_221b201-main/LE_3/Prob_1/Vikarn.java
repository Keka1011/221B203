public class Vikarn extends Kaurav {
    @Override
    public void fight() {
        System.out.println("Vikarn fights valiantly.");
    }

    @Override
    public void disobey() {
        System.out.println("Vikarn obeys the rules.");
    }

    @Override
    public void cruel() {
        System.out.println("Vikarn is kind and noble.");
    }
}
