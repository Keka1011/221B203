public abstract class Kaurav extends Bharatvanshi {
    public abstract void disobey();
    public abstract void cruel();
}
