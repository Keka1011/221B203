public class Arjun extends Pandav {
    @Override
    public void fight() {
        System.out.println("Arjun fights with precision!");
    }

    @Override
    public void obey() {
        System.out.println("Arjun is always obedient.");
    }

    @Override
    public void kind() {
        System.out.println("Arjun is kind-hearted.");
    }
}
