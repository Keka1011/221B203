class Rum extends beverage {
    @Override
    protected void amount(int amt) { 
        System.out.println(amt + " ml of Rum");
    }
}
