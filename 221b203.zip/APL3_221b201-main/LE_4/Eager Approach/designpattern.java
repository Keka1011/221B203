class designpattern{
	public static void main(String args[]){
	singleton.getinstance();
	singleton.getinstance();
	}
}