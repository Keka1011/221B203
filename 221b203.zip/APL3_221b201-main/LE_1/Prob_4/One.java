class One {
    // Parameterized constructor
    One(int x) {
        System.out.println("One's constructor called with value: " + x);
    }
}
