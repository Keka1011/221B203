class Two extends One {
    Two() {
        super(10);  // Calling the superclass constructor with an argument
        System.out.println("Two's constructor called");
    }
}