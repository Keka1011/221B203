public class Child {
    public static void main(String[] args) {
        
    }
    void show(){
        System.out.println("Hello JUET");
    }
}
