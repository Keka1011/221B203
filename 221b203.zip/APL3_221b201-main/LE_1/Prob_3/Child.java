public class Child extends Mother {
     void show(){
        System.out.println("Hello JUET");
    }
}