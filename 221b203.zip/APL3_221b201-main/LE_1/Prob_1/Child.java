class Child extends Mother{
}