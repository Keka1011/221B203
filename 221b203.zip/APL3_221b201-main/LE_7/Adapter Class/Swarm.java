public interface Swarm {
    public void swim();
    public void eat();
    public void sing();
}