public class IndianCrow implements Crow {
    public void cry() {
        System.out.println("Cow-Cow");
    }

    public void eat() {
        System.out.println("Eat Moti");
    }

    public void fly() {
        System.out.println("Fly in the Sky");
    }
}