public interface Crow {
    public void cry();
    public void eat();
    public void fly();
}
