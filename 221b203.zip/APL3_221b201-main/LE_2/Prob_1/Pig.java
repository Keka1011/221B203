class Pig extends Animal {
    @Override
    public void sound() {
        System.out.println("Pig says: Oink!");
    }
}
