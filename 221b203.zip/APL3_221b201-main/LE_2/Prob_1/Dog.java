class Dog extends Animal {
    @Override
    public void sound() {
        System.out.println("Dog says: Woof!");
    }
}
