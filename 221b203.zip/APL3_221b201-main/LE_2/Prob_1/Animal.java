abstract class Animal {
    public abstract void sound();
}
