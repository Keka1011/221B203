class Goat extends Animal {
    @Override
    public void sound() {
        System.out.println("Goat says: Baa!");
    }
}
