class Cow extends Animal {
    @Override
    public void sound() {
        System.out.println("Cow says: Moo!");
    }
}
